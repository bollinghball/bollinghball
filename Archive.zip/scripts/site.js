// Main JS should go here!
// Include scripts using Browserify by doing:
// var $ = require("jquery");
